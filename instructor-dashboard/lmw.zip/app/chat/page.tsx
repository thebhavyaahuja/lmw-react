"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { AIAssistant } from "@/components/ai-assistant"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Send, Bot, User, Sparkles, BookOpen, Users, Target, Lightbulb } from "lucide-react"

interface Message {
  id: string
  content: string
  isUser: boolean
  timestamp: Date
}

const expertiseAreas = [
  { icon: BookOpen, label: "Curriculum Design", color: "bg-green-100 text-green-700" },
  { icon: Users, label: "Student Engagement", color: "bg-emerald-100 text-emerald-700" },
  { icon: Target, label: "Learning Objectives", color: "bg-teal-100 text-teal-700" },
  { icon: Lightbulb, label: "Pedagogical Strategies", color: "bg-lime-100 text-lime-700" },
]

const quickStarters = [
  "How do I create engaging online content?",
  "What's the best way to assess student learning?",
  "How can I improve student participation?",
  "What are effective teaching strategies for my subject?",
]

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      content:
        "🎓 Hello! I'm your Subject Matter Expert assistant with deep knowledge in educational design and pedagogy. I'm here to help you create exceptional learning experiences. Whether you need help with curriculum design, student engagement strategies, or assessment methods, I'm ready to provide expert guidance tailored to your needs. What educational challenge can I help you solve today?",
      isUser: false,
      timestamp: new Date(),
    },
  ])
  const [inputValue, setInputValue] = useState("")

  const handleSendMessage = () => {
    if (!inputValue.trim()) return

    const newMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      isUser: true,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, newMessage])
    setInputValue("")

    // Simulate SME response
    setTimeout(() => {
      const smeResponse: Message = {
        id: (Date.now() + 1).toString(),
        content:
          "Excellent question! Based on current educational research and best practices, I recommend a multi-faceted approach. Let me break this down into actionable strategies that you can implement immediately. First, consider your learning objectives and how they align with your assessment methods. Then, we can explore engagement techniques that have proven effective in similar contexts.",
        isUser: false,
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, smeResponse])
    }, 1500)
  }

  const handleQuickStart = (question: string) => {
    setInputValue(question)
  }

  return (
    <>
      <Header />
      <AIAssistant />
      <main className="pt-16 min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50">
        <div className="max-w-6xl mx-auto px-6 py-8 h-[calc(100vh-4rem)] flex flex-col">
          {/* Chat Header */}
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <div className="p-4 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl text-white shadow-lg">
                <Bot className="h-8 w-8" />
              </div>
            </div>
            <h1 className="text-4xl font-bold text-gradient mb-3 tracking-tight">Subject Matter Expert Chat</h1>
            <p className="text-green-700 text-lg font-medium">Get expert guidance on educational design and pedagogy</p>

            {/* Expertise Areas */}
            <div className="flex flex-wrap justify-center gap-3 mt-6">
              {expertiseAreas.map((area, index) => (
                <Badge key={index} className={`${area.color} px-3 py-1 font-semibold flex items-center gap-2`}>
                  <area.icon className="h-4 w-4" />
                  {area.label}
                </Badge>
              ))}
            </div>
          </div>

          {/* Chat Messages */}
          <Card className="flex-1 border-0 bg-gradient-to-br from-white to-green-50/50 backdrop-blur-sm border border-green-100 p-6 mb-6 overflow-hidden flex flex-col">
            <div className="flex-1 overflow-y-auto space-y-6 mb-6">
              {messages.map((message) => (
                <div key={message.id} className={`flex gap-4 ${message.isUser ? "flex-row-reverse" : "flex-row"}`}>
                  {/* Avatar */}
                  <div
                    className={`flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center shadow-lg ${
                      message.isUser
                        ? "bg-gradient-to-br from-green-500 to-emerald-600 text-white"
                        : "bg-gradient-to-br from-white to-green-50 text-green-600 border-2 border-green-200"
                    }`}
                  >
                    {message.isUser ? <User className="h-5 w-5" /> : <Sparkles className="h-5 w-5" />}
                  </div>

                  {/* Message */}
                  <div className={`flex-1 max-w-2xl ${message.isUser ? "text-right" : "text-left"}`}>
                    <div
                      className={`inline-block p-4 rounded-2xl shadow-lg ${
                        message.isUser
                          ? "bg-gradient-to-br from-green-500 to-emerald-600 text-white"
                          : "bg-white border-2 border-green-100 text-green-800"
                      }`}
                    >
                      <p className="leading-relaxed font-medium">{message.content}</p>
                    </div>
                    <p className="text-xs text-green-600 mt-2 font-medium">{message.timestamp.toLocaleTimeString()}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Quick Starters */}
            {messages.length === 1 && (
              <div className="mb-6 bg-white/80 rounded-lg p-4 border border-green-200">
                <p className="text-sm font-semibold text-green-700 mb-3">💡 Quick conversation starters:</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {quickStarters.map((question, index) => (
                    <button
                      key={index}
                      onClick={() => handleQuickStart(question)}
                      className="text-left p-3 bg-green-50 hover:bg-green-100 rounded-lg border border-green-200 transition-colors text-sm font-medium text-green-800"
                    >
                      {question}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Input Form */}
            <div className="flex gap-4 border-t border-green-200 pt-6 bg-white/60 rounded-lg p-4">
              <Input
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Ask about course design, learning objectives, assessment strategies..."
                className="flex-1 h-12 text-base border-green-200 focus:border-green-400 bg-white/80"
                onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
              />
              <Button
                onClick={handleSendMessage}
                className="h-12 px-6 bg-gradient-to-r from-green-500 to-emerald-600 text-white shadow-lg hover:shadow-xl transition-all duration-200"
              >
                <Send className="h-5 w-5" />
              </Button>
            </div>
          </Card>
        </div>
      </main>
    </>
  )
}
