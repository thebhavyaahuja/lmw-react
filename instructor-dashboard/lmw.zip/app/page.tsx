"use client"

import { useState } from "react"
import { UploadCloud, Bot, Edit, FileQuestion, Chrome, Linkedin, GraduationCap, Monitor } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"

const examplePrompts = [
  "Create a 4-week Python syllabus",
  "Generate quiz on cellular biology",
  "Design project-based learning activities",
]

const features = [
  {
    icon: UploadCloud,
    title: "Upload Content",
    description: "Transform existing materials into structured courses",
    color: "from-blue-50 to-cyan-50",
    iconColor: "text-blue-600",
    border: "border-blue-100",
  },
  {
    icon: Bot,
    title: "AI Generation",
    description: "Generate comprehensive course structures instantly",
    color: "from-purple-50 to-pink-50",
    iconColor: "text-purple-600",
    border: "border-purple-100",
  },
  {
    icon: Edit,
    title: "Visual Editor",
    description: "Refine content with intuitive editing tools",
    color: "from-green-50 to-emerald-50",
    iconColor: "text-green-600",
    border: "border-green-100",
  },
  {
    icon: FileQuestion,
    title: "Smart Assessments",
    description: "Create adaptive quizzes and assignments",
    color: "from-orange-50 to-yellow-50",
    iconColor: "text-orange-600",
    border: "border-orange-100",
  },
]

interface Message {
  id: string
  content: string
  isUser: boolean
  timestamp: Date
}

export default function LoginPage() {
  const [messages, setMessages] = useState<Message[]>([])
  const [inputValue, setInputValue] = useState("")

  const handleSendMessage = () => {
    if (!inputValue.trim()) return

    const newMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      isUser: true,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, newMessage])
    setInputValue("")

    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: "I'd be happy to help you with that! Let me generate some ideas for your course design.",
        isUser: false,
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, botResponse])
    }, 1000)
  }

  const handlePromptClick = (prompt: string) => {
    setInputValue(prompt)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50/30">
      <div className="flex items-center justify-center min-h-screen p-6">
        {/* Login Card */}
        <Card className="w-full max-w-md shadow-2xl border-0 glass-effect">
          <CardHeader className="text-center space-y-6 pb-8">
            <div className="flex justify-center">
              <div className="p-4 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl text-white shadow-lg">
                <GraduationCap className="h-10 w-10" />
              </div>
            </div>
            <div className="space-y-2">
              <CardTitle className="text-2xl font-bold text-slate-900">Access Instructor LMW</CardTitle>
              <CardDescription className="text-slate-600 text-base">
                Sign in with your preferred account to continue
              </CardDescription>
            </div>
          </CardHeader>
          <CardContent className="space-y-4 pb-8">
            <Link href="/dashboard">
              <Button
                variant="outline"
                className="w-full h-12 gap-3 border-slate-200 hover:bg-slate-50 transition-all duration-200 bg-white/80 text-slate-700 font-medium"
              >
                <Chrome className="h-5 w-5 text-red-500" />
                Continue with Google
              </Button>
            </Link>

            <Link href="/dashboard">
              <Button
                variant="outline"
                className="w-full h-12 gap-3 border-slate-200 hover:bg-slate-50 transition-all duration-200 bg-white/80 text-slate-700 font-medium"
              >
                <Monitor className="h-5 w-5 text-blue-500" />
                Continue with Microsoft
              </Button>
            </Link>

            <Link href="/dashboard">
              <Button
                variant="outline"
                className="w-full h-12 gap-3 border-slate-200 hover:bg-slate-50 transition-all duration-200 bg-white/80 text-slate-700 font-medium"
              >
                <Linkedin className="h-5 w-5 text-blue-600" />
                Continue with LinkedIn
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
